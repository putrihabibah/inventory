<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
   public function __construct(){
      parent ::__construct();
      $this->load->model('M_pengguna');
      $this->load->model('M_ruangan');
      $this->load->model('M_barang');
  }

  public function index(){
   $data['content']='menu_user';
   $this->load->view('template',$data);
  }

  public function user_menu_dua(){
   $data['content']='menu_user_dua';
   $this->load->view('template',$data);
  }
  
}