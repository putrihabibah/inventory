<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('M_Auth');
    }
	public function index()
{
    $this->form_validation->set_rules('username', 'Username', 'required|trim');
    $this->form_validation->set_rules('password', 'Password', 'required|trim');

    if ($this->form_validation->run() == false) {
        $this->load->view('auth/login');
    } else {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
    

        $user = $this->M_Auth->get_data_pengguna($username);
        

        // Cek data pengguna langsung dari database
        if ($user) {
            // Verifikasi kata sandi
            if ($password === $user['password']) {
                $data = [
                    'username'=> $user['nama'],
                    'role_id'=> $user['role_id'],
                    'usname'=> $user['username'],
                ];
                // Verifikasi berhasil
                $this->session->set_userdata($data);
                if($data['role_id'] == 1){
                    redirect('dashboard');
                } else {
                    redirect('user');
                }
            } else {
                // Verifikasi gagal
                $this->session->set_flashdata('message', 'kata sandi salah!');
                redirect('auth');
            }
        } else {
            // Data pengguna tidak ditemukan
            $this->session->set_flashdata('message', 'nama pengguna tidak terdaptar!');
            redirect('auth');
        }
    }
}

}