<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends CI_Controller {

    public function __construct(){

        parent ::__construct();
        $this->load->model('M_pengguna');
        $this->load->model('M_ruangan');
        $this->load->model('M_barang');


    }
public function index()
{ 
    $data['content']='content';
    $this->load->view('template',$data);
}

public function detail_data_ruangan($id_ruang_office){
    $where=array('id_ruangan'=>$id_ruang_office);
    $data['data_barang']= $this->M_ruangan->get_data_ruangan('tbl_barang', $where)->result();
    $data['content']='admin/tampilan';
    $this->load->view('template',$data);
}

public function data_pengguna()
{
    $data['tbl_pengguna'] = $this->M_pengguna->show_data()->result();
    $data['content']='admin/data_pengguna';
    $this->load->view('template',$data);
}
public function form_pengguna()
{
    $data['content']='admin/form_pengguna';
    $this->load->view('template',$data);
}
public function add_data(){
    $data ['nama'] = $this->input->post('nama');
    $data ['username'] = $this->input->post('username');
    $data ['password'] = $this->input->post('password');
    $data ['role_id'] = $this->input->post('role_id');


    if ($this->M_pengguna->add_data('tbl_pengguna', $data)) {
        // Penyisipan berhasil
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Selamat! Data Berhasil ditambahkan.</div>');
    } else {
        // Penyisipan gagal
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> Gagal menambahkan data. </div>');
    }

   redirect('Dashboard/data_pengguna','refresh');
}

//data barang
public function data_barang()
{
    $data['tbl_barang'] = $this->M_barang->show_data()->result();
    $data['content']='admin/data_barang';
    $this->load->view('template',$data);
}

public function form_barang()
{
    $data['content']='admin/form_barang';
    $data['ruangan']= $this->M_barang->get_data_ruangan()->result();
    $this->load->view('template',$data);
}



public function add_databarang(){
    $data ['kd_inventaris'] = $this->input->post('kd_inventaris');
    $data ['nm_barang'] = $this->input->post('nm_barang');
    $data ['merk'] = $this->input->post('merk');
    $data ['ukuran'] = $this->input->post('ukuran');
    $data ['jumlah'] = $this->input->post('jumlah');
    $data ['satuan'] = $this->input->post('satuan');
    $data ['tahun'] = $this->input->post('tahun');
    $data ['kondisi'] = $this->input->post('kondisi');
    $data ['id_ruangan'] = $this->input->post('id_ruangan');


    if ($this->M_barang->add_databarang('tbl_barang', $data)) {
        // Penyisipan berhasil
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Selamat! Data Berhasil ditambahkan .</div>');
    } else {
        // Penyisipan gagal
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> Gagal menambahkan data. </div>');
    }

   redirect('Dashboard/data_barang','refresh');
}

public function edit_barang($id_barang) {
    $data['ruangan']= $this->M_barang->get_data_ruangan()->result_array();
    $where = array('id_barang' => $id_barang);
    $data['tbl_barang'] = $this->M_barang->edit_barang('tbl_barang', $where)->result();
    $data['content'] = 'admin/edit_barang';
    $this->load->view('template', $data);
}
public function update_databarang($id_barang)
{
    $data ['kd_inventaris'] = $this->input->post('kd_inventaris');
    $data ['nm_barang'] = $this->input->post('nm_barang');
    $data ['merk'] = $this->input->post('merk');
    $data ['ukuran'] = $this->input->post('ukuran');
    $data ['jumlah'] = $this->input->post('jumlah');
    $data ['satuan'] = $this->input->post('satuan');
    $data ['tahun'] = $this->input->post('tahun');
    $data ['kondisi'] = $this->input->post('kondisi');
    $data ['id_ruangan'] = $this->input->post('id_ruangan');


    $where = array('id_barang' => $id_barang);
    $this->M_barang->update_databarang($where, $data, 'tbl_barang');
    redirect('dashboard/data_barang','refresh');
    
}

public function deletebarang($id_barang)
{
    $where = array('id_barang' => $id_barang );
    $this->M_barang->deletebarang($where);
    redirect('dashboard/data_barang','refresh');
}

//DATA RUANGAN
public function data_ruangan()
{
    $data['tbl_ruang_office'] = $this->M_ruangan->show_data()->result();
    $data['content']='admin/data_ruangan';
    $this->load->view('template',$data);
}
public function form_ruangan()
{
    $data['content']='admin/form_ruangan';
    $this->load->view('template',$data);
}


public function add_dataruangan(){
  
    $data ['nm_ruangan'] = $this->input->post('nm_ruangan');
    

    if ($this->M_ruangan->add_dataruangan('tbl_ruang_office', $data)) {
        // Penyisipan berhasil
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Selamat! Data Berhasil ditambahkan .</div>');
    } else {
        // Penyisipan gagal
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> Gagal menambahkan data. </div>');
    }

   redirect('Dashboard/data_ruangan','refresh');
}

public function edit_ruangan($id_ruang_office) {
    $where = array('id_ruang_office' => $id_ruang_office);
    $data['tbl_ruangan'] = $this->M_ruangan->edit_ruangan('tbl_ruang_office', $where)->result();
    $data['content'] = 'admin/edit_ruangan';
    $this->load->view('template', $data);
}
public function update_dataruangan($id_ruang_office)
{
    
    $data ['nm_ruangan'] = $this->input->post('nm_ruangan');
  
    $where = array('id_ruang_office' => $id_ruang_office);
    $this->M_ruangan->update_dataruangan($where, $data, 'tbl_ruang_office');
    redirect('dashboard/data_ruangan','refresh');
    
}

public function deleteruang($id_ruang_office)
{
    $where = array('id_ruang_office' => $id_ruang_office );
    $this->M_ruangan->delete($where);
    redirect('dashboard/data_ruangan','refresh');
}
}