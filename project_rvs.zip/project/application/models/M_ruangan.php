<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_ruangan extends CI_Model {
public function show_data()
{
$show_data = $this->db->get('tbl_ruang_office');
return $show_data;
}
public function add_dataruangan($table,$data)
{
$this->db->insert($table,$data);
}
public function edit_ruangan($table, $id_ruangan)
{
    $edit = $this->db->get_where($table, $id_ruangan);
    return $edit;
}

public function update_dataruangan($where,$data,$table)
{
$this->db->where($where);
$this->db->update($table,$data);
}
public function deleteruang($where)
{
    $this->db->delete('tbl_ruang_office',$where);
    
}
public function get_data_ruangan($tbl_barang, $where){

    $get= $this->db->get_where($tbl_barang, $where);
    return $get;
}
}