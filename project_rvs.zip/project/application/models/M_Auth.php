<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_Auth extends CI_Model {
public function get_data($username)
{
return $this->db->get_where('tbl_pengguna',['username' => $username])->row_array();
}
public function Insert_data($data)
{
$this->db->insert('tbl_pengguna', $data);
}

// ambil data pengguna
public function get_data_pengguna($username){
    return $this->db->get_where('tbl_pengguna', ['username' => $username])->row_array();
}
}