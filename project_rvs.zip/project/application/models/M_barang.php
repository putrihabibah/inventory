<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_barang extends CI_Model {
public function show_data()
{
$show_data = $this->db->get('tbl_barang');
return $show_data;
}
public function add_databarang($table,$data)
{
$this->db->insert($table,$data);
}
public function edit_barang($table, $id_barang)
{
    $edit = $this->db->get_where($table, $id_barang);
    return $edit;
}

public function update_databarang($where,$data,$table)
{
$this->db->where($where);
$this->db->update($table,$data);
}
public function deletebarang($where)
{
    $this->db->delete('tbl_barang',$where);
    
}

public function get_data_ruangan(){
    return $this->db->get('tbl_ruang_office');
}
}