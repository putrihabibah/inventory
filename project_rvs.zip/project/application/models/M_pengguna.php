<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_pengguna extends CI_Model {
public function show_data()
{
$show_data = $this->db->get('tbl_pengguna');
return $show_data;
}
public function add_data($table,$data)
{
$this->db->insert($table,$data);
}

}