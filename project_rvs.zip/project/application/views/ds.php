<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>INVENAS</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" href="<?= base_url(); ?>assets/images/logo/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?= base_url(); ?>assets/images/logo/favicon.png">

    <!-- core dependcies css -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/bootstrap/dist/css/bootstrap.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/PACE/themes/blue/pace-theme-minimal.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/perfect-scrollbar/css/perfect-scrollbar.min.css" />

    <!-- page css -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/jvectormap-master/jquery-jvectormap-2.0.3.css" />

    <!-- core css -->
    <link href="<?= base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/themify-icons.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/app.css" rel="stylesheet">
</head>

<body>
    <div class="app header-info-gradient side-nav-dark">
        <div class="layout">
            <!-- Header START -->
            <div class="header navbar">
                <div class="header-container">
                    <div class="nav-logo">
                        <a href="index.html">
                            <div class="logo logo-dark" style="background-image: url('<?= base_url(); ?>assets/images/logo/logo.png')"></div>
                            <div class="logo logo-white" style="background-image: url('<?= base_url(); ?>assets/images/logo/logo-white.png')"></div>
                        </a>
                    </div>
                    <ul class="nav-left">
                        <li>
                            <a class="sidenav-fold-toggler" href="javascript:void(0);">
                                <i class="mdi mdi-menu"></i>
                            </a>
                            <a class="sidenav-expand-toggler" href="javascript:void(0);">
                                <i class="mdi mdi-menu"></i>
                            </a>
                        </li>
                        <li class="search-box">
                            <a class="search-toggle" href="javascript:void(0);">
                                <i class="search-icon mdi mdi-magnify"></i>
                                <i class="search-icon-close mdi mdi-close-circle-outline"></i>
                            </a>
                        </li>
                        <li class="search-input">
                            <input class="form-control" type="text" placeholder="Type to search...">
                            <div class="search-predict">
                                <div class="search-wrapper scrollable">
                                    <div class="p-v-10">
                                        <span class="display-block m-v-5 p-h-20 text-gray">
                                            <i class="ti-file p-r-5"></i>
                                            <span>Files</span>
                                        </span>
                                        <ul class="list-media">
                                            <li class="list-item">
                                                <a href="javascript:void(0);" class="media-hover p-h-20">
                                                    <div class="media-img">
                                                        <div class="icon-avatar bg-success">
                                                            <i class="mdi mdi-file-outline"></i>
                                                        </div>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="m-h-20 border top"></div>
                                    <div class="p-v-10">
                                        <span class="display-block m-v-5 p-h-20 text-gray">
                                            <i class="ti-user p-r-5"></i>
                                            <span>Members</span>
                                        </span>
                                        <ul class="list-media">
                                            <li class="list-item">
                                                <a href="javascript:void(0);" class="conversation-toggler media-hover p-h-20">
                                                    <div class="media-img">
                                                        <img src="<?= base_url(); ?>assets/images/avatars/thumb-3.jpg" alt="">
                                                    </div>
                                                    <div class="info">
                                                        <span class="title p-t-10">Debra Stewart</span>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="list-item">
                                                <a href="javascript:void(0);" class="conversation-toggler media-hover p-h-20">
                                                    <div class="media-img">
                                                        <img src="<?= base_url(); ?>assets/images/avatars/thumb-5.jpg" alt="">
                                                    </div>
                                                    <div class="info">
                                                        <span class="title p-t-10">Jane Hunt</span>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="search-footer">
                                    <span>You are Searching for '<b class="text-dark"><span class="serach-text-bind"></span></b>'</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <ul class="nav-right">
                        <li class="dropdown dropdown-animated scale-left">
                        
                            <ul class="dropdown-menu dropdown-grid col-3 dropdown-lg">
                                
                                    <ul class="list-media overflow-y-auto relative scrollable" style="max-height: 300px">
                                        <li class="list-item border bottom">
                                            <a href="javascript:void(0);" class="media-hover p-15">
                                                <div class="media-img">
                                                    <div class="icon-avatar bg-primary">
                                                        <i class="ti-settings"></i>
                                                    </div>
                                                </div>
                                               
                                            </a>
                                        </li>
                                    </ul>
                                
                                
                                
                            </ul>
                        </li>
                        <li class="user-profile dropdown dropdown-animated scale-left">
                            <a href="" class="dropdown-toggle" data-toggle="dropdown">
                                <img class="profile-img img-fluid" src="<?= base_url(); ?>assets/images/avatars/thumb-13.jpg" alt="">
                            </a>
                            <ul class="dropdown-menu dropdown-md p-v-0">
                                <li>
                                    <ul class="list-media">
                                        <li class="list-item p-15">
                                            <div class="media-img">
                                                <img src="<?= base_url(); ?>assets/images/avatars/thumb-13.jpg" alt="">
                                            </div>
                                           <!-- dashboard.php -->

                                            <div class="info">
                                            <span class="title text-semibold"><p>selamat datang <br><?php echo $username; ?></span>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li role="separator" class="divider"></li> 
                               
            
                                
                                <li>
                                    <a href="<?php echo base_url('auth');?>">
                                        <i class="ti-power-off p-r-10"></i>
                                        <span>Logout</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="m-r-10">
                            <a class="quick-view-toggler" href="javascript:void(0);">
                                <i class="mdi mdi-format-indent-decrease"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Header END -->

            <!-- Side Nav START -->
            <div class="side-nav expand-lg">
                <div class="side-nav-inner">
                    <ul class="side-nav-menu scrollable">
                        <li class="side-nav-header">
                            <span>Menu</span>
                        </li>
                        <li class="nav-item dropdown open">
                            <a class="dropdown-toggle" href="javascript:void(0);">
                                <span class="icon-holder">
                                    <i class="mdi mdi-account"></i>
                                </span>
                                <span class="title">Admin</span>
                                <span class="arrow">
                                    <i class="mdi mdi-chevron-right"></i>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="index.html">Input petugas</a>
                                </li>
                                <li>
                                    <a href="index-analytical.html">Lihat Petugas</a>
                                </li>
                               
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="javascript:void(0);">
                                <span class="icon-holder">
                                    <i class="mdi mdi-garage"></i>
                                </span>
                                <span class="title">Data Ruangan</span>
                                <span class="arrow">
                                    <i class="mdi mdi-chevron-right"></i>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="email.html">Input Ruangan</a>
                                </li>
                                <li>
                                    <a href="calendar.html">Lihat Ruangan</a>
                                </li>
                               
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="javascript:void(0);">
                                <span class="icon-holder">
									<i class="mdi mdi-vector-arrange-above"></i>
								</span>
                                <span class="title">Data Barang</span>
                                <span class="arrow">
									<i class="mdi mdi-chevron-right"></i>
								</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="alert.html">Input Barang</a>
                                </li>
                                <li>
                                    <a href="badge.html">Lihat Barang</a>
                                </li>
                                <li>
                              
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="javascript:void(0);">
                                <span class="icon-holder">
                                    <i class="mdi mdi-compass-outline"></i>
                                </span>
                                <span class="title">Laporan</span>
                                <span class="arrow">
                                    <i class="mdi mdi-chevron-right"></i>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="accordion.html">Lihat Laporan</a>
                                </li>
                               
                            </ul>
                        </li>
                       
                       
                      
                        
                                        
                                
                                
                            
                        
                    </ul>
                </div>
            </div>
            <!-- Side Nav END -->

            <!-- Page Container START -->
            <div class="page-container">
                <div class="main-content">
                    <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="card">
                                   <div class="card-header">
                                       <h4 class="card-title">Earning</h4>
                                   </div>
                                   <div class="card-body">
                                        <h2 class="font-weight-light font-size-28 m-b-0">$26,932</h2>
                                        <span>Sales:</span>
                                        <span class="text-dark">1,782</span>
                                   </div>
                                   <div class="m-b-15">
                                        <canvas id="earning-chart" class="chart" style="height: 170px;"></canvas>
                                    </div>
                                    <div class="row p-v-25">
                                        <div class="col border right">
                                            <div class="text-center">
                                                <span class="text-semibold d-block opacity-07">Margin</span>
                                                <span class="text-semibold">$17,312</span>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="text-center">
                                                <span class="text-semibold d-block opacity-07">Fees</span>
                                                <span class="text-semibold">$9,620</span>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>
                <!-- Content Wrapper END -->

                <!-- Footer START -->
                <footer class="content-footer">
                    <div class="footer">
                        <div class="copyright">
                            <span>Copyright © 2023 All rights reserved.</span>
                            <span class="go-right">
                                <a href="" class="text-gray m-r-15">Term &amp; Conditions</a>
                                <a href="" class="text-gray">Privacy &amp; Policy</a>
                            </span>
                        </div>
                    </div>
                </footer>
                <!-- Footer END -->

            </div>
            <!-- Page Container END -->

        </div>
    </div>

    <!-- build:js assets/js/vendor.js -->
    <!-- core dependcies js -->
    <script src="<?= base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/PACE/pace.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>     
    <script src="<?= base_url(); ?>assets/vendor/d3/d3.min.js"></script>
    <!-- endbuild -->

    <!-- build:js assets/js/app.min.js -->
    <!-- core js -->
    <script src="<?= base_url(); ?>assets/js/app.js"></script>
    <!-- configurator js -->
    <script src="<?= base_url(); ?>assets/js/configurator.js"></script>
    <!-- endbuild -->

    <!-- page js -->
    <script src="<?= base_url(); ?>assets/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/jvectormap-master/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/maps/vector-map-lib/jquery-jvectormap-world-mill.js"></script>
    <script src="<?= base_url(); ?>assets/js/dashboard/saas.js"></script>
    
</body>

</html>