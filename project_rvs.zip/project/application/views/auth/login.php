<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Inventory</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" href="<?= base_url(); ?>assets/images/logo/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?= base_url('assets/'); ?>assets/images/logo/favicon.png">

    <!-- core dependcies css -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/bootstrap/dist/css/bootstrap.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/PACE/themes/blue/pace-theme-minimal.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/perfect-scrollbar/css/perfect-scrollbar.min.css" />

    <!-- page css -->

    <!-- core css -->
    <link href="<?= base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/themify-icons.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/app.css" rel="stylesheet">
</head>

<body>
    <div class="app">
        <div class="layout bg-gradient-info">
            <div class="container">
                <div class="row full-height align-items-center">
                    <div class="col-md-7 d-none d-md-block">
                       
                        <div class="m-t-15 m-l-20">
                            <h1 class="font-weight-light font-size-35 text-white"> INVENAS <br>(Inventory Asset System) </h1>
                            <p class="text-white width-70 text-opacity m-t-25 font-size-16">Horizon University Indonesia</p>
                    
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="card card-shadow">
                            <div class="card-body">
                                <div class="p-h-15 p-v-40">
                                    <h2>Login</h2>
                                    <p class="m-b-15 font-size-13">Silakan masukan nama pengguna dan kata sandi Anda</p>
                                    <?= $this->session->flashdata('message'); ?>
                                    <form class="user" method="post" action="<?=base_url('auth');?>">
                                        <div class="form-group">
                                            <input type="text" name="username" value="<?= set_value('username'); ?>" class="form-control form-control-user"
                                                id="username" placeholder="username ">
                                                <?= form_error('username','<small class="text-danger pl-3">','</small>'); ?>
                                        </div>
                                        <div class="form-group">
                                        <input type="password" class="form-control form-control-user"
                                                id="password" name="password" placeholder="kata sandi">
                                                <?= form_error('password','<small class="text-danger pl-3">','</small>'); ?>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-gradient-info btn-block m-t-25">masuk</button>

                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- build:js assets/js/vendor.js -->
    <!-- core dependcies js -->
    <script src="<?= base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/PACE/pace.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>     
    <script src="<?= base_url(); ?>assets/vendor/d3/d3.min.js"></script>
    <!-- endbuild -->

    <!-- build:js assets/js/app.min.js -->
    <!-- core js -->
    <script src="<?= base_url(); ?>assets/js/app.js"></script>
    <!-- configurator js -->
    <script src="<?= base_url(); ?>assets/js/configurator.js"></script>
    <!-- endbuild -->

    <!-- page js -->
    
</body>

</html>