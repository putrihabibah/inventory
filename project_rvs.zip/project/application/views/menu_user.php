<div class="page-container">
   <div class="main-content">
      <div class="container-fluid">
         <div class="row">
            <h1>Menu User 1</h1>
         </div>
      </div>
   </div>