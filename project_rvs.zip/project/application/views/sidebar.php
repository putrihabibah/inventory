<div class="side-nav expand-lg">
   <div class="side-nav-inner">
      <ul class="side-nav-menu scrollable">
         <?php if($this->session->userdata('role_id') == 1) : ?>
         <li class="side-nav-header">
            <span>Menu Admin</span>
         </li>
         <li class="nav-item">
            <a href="<?= base_url('dashboard'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-view-dashboard"></i> <!-- Ganti dengan ikon yang sesuai -->
               </span>
               <span class="title">Dashboard</span>
            </a>
         </li>
         <li class="nav-item">
            <a href="<?= base_url('Dashboard/data_pengguna'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-account"></i>
               </span>
               <span class="title">User</span>
            </a>
         </li>
         <li class="nav-item">
            <a href="<?= base_url('Dashboard/data_ruangan'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-garage"></i>
               </span>
               <span class="title">Data Ruangan</span>
            </a>
         </li>
         <li class="nav-item">
            <a href="<?= base_url('Dashboard/data_barang'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-archive"></i> <!-- Ganti dengan ikon yang sesuai -->
               </span>
               <span class="title">Data Barang</span>
            </a>
         </li>
         <!-- <li class="nav-item dropdown">
            <a class="dropdown-toggle" href="javascript:void(0);">
               <span class="icon-holder">
                  <i class="mdi mdi-compass-outline"></i>
               </span>
               <span class="title">Laporan</span>
               <span class="arrow">
                  <i class="mdi mdi-chevron-right"></i>
               </span>
            </a>
            <ul class="dropdown-menu">
               <li>
                  <a href="accordion.html">Lihat Laporan</a>
               </li>

            </ul>
         </li>
         </li> -->
         <?php endif; ?>

         <!-- menu user biasa -->
         <!-- judul menu -->
         <li class="side-nav-header">
            <span>Menu Staff</span>
         </li>
         <!-- end judul menu -->
         <li class="nav-item">
            <a href="<?= base_url('user'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-garage"></i>
               </span>
               <span class="title">Pengajuan</span>
            </a>
         </li>
         <li class="nav-item">
            <a href="<?= base_url('user/user_menu_dua'); ?>">
               <span class="icon-holder">
                  <i class="mdi mdi-garage"></i>
               </span>
               <span class="title">Menu User Biasa 2</span>
            </a>
         </li>
         <!-- end menu user biasa -->
      </ul>
   </div>
</div>