<div class="page-container" >
    <div class="main-content">
        <div class="card">
            <div class="card-header border bottom">
                <h4 class="card-title">Data Inventory Barang</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-8">
                        <form action="<?php echo site_url('Dashboard/add_data') ?>" method="post" enctype="multipart/form-data" >
                    <div class="form-group row">
                        <label for="nama" class="col-sm-2 col-form-label control-label">Nama</label>
                        
                            <input type="text" name="nama" class="form-control" id="nama" placeholder="nama">
                        
                    </div>
                    <div class="form-group row">
                        <label for="username" class="col-sm-2 col-form-label control-label">Username</label>
                       
                            <input type="text" name="username" class="form-control" id="username" placeholder="username" required>
                        
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label control-label">Password</label>
                       
                            <input type="password"name="password" class="form-control" id="password" placeholder="Password" required>
                        
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label control-label">Role_id</label>
                       
                            <input type="role_id" name="role_id" class="form-control" id="role_id" placeholder="Password" required>
                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12 text-right">
                            <button class="btn btn-danger btn-rounded" type='Reset' value="Reset">Reset</button>
                            <button class="btn btn-info btn-rounded btn-float">Tambah</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
