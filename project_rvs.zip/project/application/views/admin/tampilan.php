<div class="page-container">
                <!-- Content Wrapper START -->
                <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <h2 class="header-title">Data Inventory Ruangan</h2>
                            <div class="header-sub-title">
                                <nav class="breadcrumb breadcrumb-dash">
                                    <a href="#" class="breadcrumb-item"><i class="ti-home p-r-5"></i>Home</a>
                                    <a class="breadcrumb-item" href="#">Tables</a>
                                    <span class="breadcrumb-item active">Data Table</span>
                                </nav>
                            </div>
                        </div>  
                        <div class="card">
                            <div class="card-body">
                            <!-- <a href="<?php echo site_url('dashboard/form_ruangan') ?>" class="btn btn-info btn-rounded btn-float">Tambah</a> -->
                                <div class="table-overflow">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode Inventaris</th>
                                                <th>Nama Barang</th>
                                                <th>Merk</th>
                                                <th>Ukuran</th>
                                                <th>Jumlah</th>
                                                <th>Satuan</th>
                                                <th>Tahun</th>
                                                <th>Kondisi</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($data_barang as $key) {
                                            ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $key->kd_inventaris; ?></td>
                                                <td><?php echo $key->nm_barang; ?></td>
                                                <td><?php echo $key->merk; ?></td>
                                                <td><?php echo $key->ukuran; ?></td>
                                                <td><?php echo $key->jumlah; ?></td>
                                                <td><?php echo $key->satuan; ?></td>
                                                <td><?php echo $key->tahun; ?></td>
                                                <td><?php echo $key->kondisi; ?></td>
                                                <td>
                                                    <a href="<?php echo site_url('dashboard/edit_barang/' . $key->id_barang); ?>"  class="btn btn-warning btn-rounded btn-float">Edit</a>
                                                    <a href="<?php echo site_url('dashboard/deletebarang/'. $key->id_barang); ?>" class="btn btn-danger btn-rounded btn-float" onclick="myFunction();">Hapus</a>
                                                </td>
                                            </tr>
                                            <?php
                                            }
                                            ?>
                                            </tbody>                           
                                    </table>
                                </div> 
                            </div>       
                        </div>   
                    </div>
                </div>
                <!-- Content Wrapper END -->
                <script>
                    function myFunction() {
                        if(!confirm('Are you sure to delete this item! ?')){
                            event.preventDefault();
                            return;
                        }
                        return true;
                    }
                </script>
</div>