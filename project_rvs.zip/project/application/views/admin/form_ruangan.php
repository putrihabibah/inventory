<div class="page-container">

<div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <h2 class="header-title">Form Input Data Inventory Ruangan</h2>
                            <div class="header-sub-title">
                                <nav class="breadcrumb breadcrumb-dash">
                                    <a href="#" class="breadcrumb-item"><i class="ti-home p-r-5"></i>Home</a>
                                    <a class="breadcrumb-item" href="#">Forms</a>
                                    <span class="breadcrumb-item active">Data Inventory Ruangan</span>
                                </nav>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header border bottom">
                                <h4 class="card-title">Data Inventory Ruangan</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <form action="<?php echo site_url('dashboard/add_dataruangan') ?>" method="post" enctype="multipart/form-data">
                                            
                                            <div class="form-group row">
                                                <label for="name">Nama Ruangan*</label>
                                                <input class="form-control" type="text" name="nm_ruangan" placeholder="Nama Ruangan" required/>
                                            </div>
                                            <button class="btn btn-gradient-success">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
                <!-- Content Wrapper END -->
</div>
