<div class="page-container">
                <!-- Content Wrapper START -->
                <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <h2 class="header-title">Data Inventory Barang</h2>
                            <!-- <div class="header-sub-title">
                                <nav class="breadcrumb breadcrumb-dash">
                                    <a href="#" class="breadcrumb-item"><i class="ti-home p-r-5"></i>Home</a>
                                    <a class="breadcrumb-item" href="#">Tables</a>
                                    <span class="breadcrumb-item active">Data Table</span>
                                </nav>
                            </div> -->
                        </div>  
                        <div class="card">
                            <div class="card-body">
                            <a href="<?php echo site_url('dashboard/form_barang') ?>" class="btn btn-info btn-rounded btn-float">Tambah</a>
                                <div class="table-overflow">
                                <table id="dt-opt" class="table table-hover table-xl">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode Inventaris</th>
                                                <th>Nama Barang</th>
                                                <th>Merk</th>
                                                <th>Ukuran</th>
                                                <th>Jumlah</th>
                                                <th>Satuan</th>
                                                <th>Tahun</th>
                                                <th>Kondisi</th>
                                                <th>Nama Ruangan</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($tbl_barang as $key) {
                                            ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $key->kd_inventaris; ?></td>
                                                <td><?php echo $key->nm_barang; ?></td>
                                                <td><?php echo $key->merk; ?></td>
                                                <td><?php echo $key->ukuran; ?></td>
                                                <td><?php echo $key->jumlah; ?></td>
                                                <td><?php echo $key->satuan; ?></td>
                                                <td><?php echo $key->tahun; ?></td>
                                                <td><?php echo $key->kondisi; ?></td>
                                                <?php 
                                                $ruangan= $key->id_ruangan;
                                                $nm_ruangan= $this->db->get_where('tbl_ruang_office', array('id_ruang_office'=>$ruangan))->result_array();
                                                foreach($nm_ruangan as $nm){?>
                                                    <td><?php echo $nm['nm_ruangan'] ?></td>

                                                <?php }?>
                                
                                                


                                                <td>
                                                    <a href="<?php echo site_url('dashboard/edit_barang/' . $key->id_barang); ?>"  class="text-gray m-r-15"><i class="ti-pencil"></i></a>
                                                    <a href="<?php echo site_url('dashboard/deletebarang/'. $key->id_barang); ?>" class="text-gray" onclick="myFunction();"><i class="ti-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                            }
                                            ?>
                                            </tbody>                           
                                    </table>
                                </div> 
                            </div>       
                        </div>   
                    </div>
                </div>
                <!-- Content Wrapper END -->
                <script>
                    function myFunction() {
                        if(!confirm('Are you sure to delete this item! ?')){
                            event.preventDefault();
                            return;
                        }
                        return true;
                    }
                </script>
</div>