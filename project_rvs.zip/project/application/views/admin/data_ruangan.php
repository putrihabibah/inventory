<div class="page-container">
                <!-- Content Wrapper START -->
                <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <h2 class="header-title">Data Inventory Ruangan</h2>
                            <div class="header-sub-title">
                                <nav class="breadcrumb breadcrumb-dash">
                                    <a href="#" class="breadcrumb-item"><i class="ti-home p-r-5"></i>Home</a>
                                    <a class="breadcrumb-item" href="#">Tables</a>
                                    <span class="breadcrumb-item active">Data Table</span>
                                </nav>
                            </div>
                        </div>  
                        <div class="card">
                            <div class="card-body">
                            <a href="<?php echo site_url('dashboard/form_ruangan') ?>" class="btn btn-info btn-rounded btn-float">Tambah</a>
                                <div class="table-overflow">
                                <table id="dt-opt" class="table table-hover table-xl">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Ruangan</th>
                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($tbl_ruang_office as $key) {
                                            ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $key->nm_ruangan; ?></td>
                                               
                                                <td>
                                                    <a href="<?php echo site_url('dashboard/detail_data_ruangan/' . $key->id_ruang_office); ?>"   class="text-gray m-r-15"><i class="ti-eye"></i></a>
                                                    <a href="<?php echo site_url('dashboard/deleteruang/'. $key->id_ruang_office); ?>" class="text-gray" onclick="myFunction();"><i class="ti-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                            }
                                            ?>
                                            </tbody>                           
                                    </table>
                                </div> 
                            </div>       
                        </div>   
                    </div>
                </div>
                <!-- Content Wrapper END -->
                <script>
                    function myFunction() {
                        if(!confirm('Are you sure to delete this item! ?')){
                            event.preventDefault();
                            return;
                        }
                        return true;
                    }
                </script>
</div>