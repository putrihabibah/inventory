<div class="page-container">
<?php
foreach ($tbl_barang as $row) {
?>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success" role="alert">
<?php echo $this->session->flashdata('success'); ?>
</div>
<?php endif; ?>
<div class="card mb-3">
<div class="card-header">
<a href="<?php echo site_url('dashboard/data_barang') ?>"><i class="fasfa-arrow-left"></i> Back</a>
</div>
<div class="card-body">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <form action="<?php echo site_url('dashboard/update_databarang/'.$row->id_barang) ?>" method="post" enctype="multipart/form-data">
                                            <div class="form-group row">
                                                <label for="name">Kode Inventaris*</label>
                                                <input class="form-control" type="text" name="kd_inventaris"value="<?php echo $row->kd_inventaris; ?>"  placeholder="Kode Inventaris" readonly/>
                                                
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Nama Barang*</label>
                                                <input class="form-control" type="text" name="nm_barang" value="<?php echo $row->nm_barang; ?>" placeholder="Nama Barang" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Merk*</label>
                                                <input class="form-control" type="text" name="merk" value="<?php echo $row->merk; ?>" placeholder="Merk" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Ukuran*</label>
                                                <input class="form-control" type="text" name="ukuran" value="<?php echo $row->ukuran; ?>" placeholder="Ukuran" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">jumlah*</label>
                                                <input class="form-control" type="text" name="jumlah" value="<?php echo $row->jumlah; ?>" placeholder="Nama Mahasiswa" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Satuan*</label>
                                                    <select name="satuan" class="form-control">
                                                        <option <?php if($row->satuan == "buah"){echo "selected";} ?> value="buah">Buah</option>
                                                        <option  <?php if($row->satuan == "unit"){echo "selected";} ?> value="unit">Unit</option>
                                                    </select>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Tahun*</label>
                                                <input class="form-control" type="text" name="tahun" value="<?php echo $row->tahun; ?>" placeholder="Tahun" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Kondisi*</label>
                                                <input class="form-control" type="text" name="kondisi" value="<?php echo $row->tahun; ?>" placeholder="Kondisi" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Nama Ruangan*</label>
                                                    <select name="id_ruangan" class="form-control">
                                                        <?php foreach($ruangan as $key): ?>
                                                        <option value="<?php echo $key['id_ruang_office'] ?>"><?php echo $key['nm_ruangan'] ?> </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                            </div>
                                            <button type="submit" class="btn btn-gradient-success">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
</div>
</div>
<?php } ?>