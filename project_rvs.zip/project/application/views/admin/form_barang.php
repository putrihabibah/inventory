<div class="page-container">

<div class="main-content">
                  
                        <div class="card">
                            <div class="card-header border bottom">
                                <h4 class="card-title">Data Inventory Barang</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <form action="<?php echo site_url('dashboard/add_databarang') ?>" method="post" enctype="multipart/form-data">
                                            <div class="form-group row">
                                                <label for="name">Kode Inventaris*</label>
                                                <input class="form-control" type="text" name="kd_inventaris" placeholder="Kode Inventaris" required/>
                                                
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Nama Barang*</label>
                                                <input class="form-control" type="text" name="nm_barang" placeholder="Nama Barang" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Merk*</label>
                                                <input class="form-control" type="text" name="merk" placeholder="Merk" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Ukuran*</label>
                                                <input class="form-control" type="text" name="ukuran" placeholder="Ukuran" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Jumlah*</label>
                                                <input class="form-control" type="text" name="jumlah" placeholder="Jumlah" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Satuan*</label>
                                                    <select name="satuan" class="form-control">
                                                        <option value="buah">Buah</option>
                                                        <option value="unit">Unit</option>
                                                    </select>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Tahun*</label>
                                                <input class="form-control" type="text" name="tahun" placeholder="Tahun" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Kondisi*</label>
                                                <input class="form-control" type="text" name="kondisi" placeholder="Kondisi" required/>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name">Nama Ruangan*</label>
                                                    <select name="id_ruangan" class="form-control">
                                                        <?php foreach($ruangan as $key): ?>
                                                        <option value="<?php echo $key->id_ruang_office ?>"><?php echo $key->nm_ruangan ?> </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                            </div>
                                            <button class="btn btn-gradient-success">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
                <!-- Content Wrapper END -->
</div>
