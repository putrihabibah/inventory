<div class="page-container">
<?php
foreach ($tbl_ruang_office as $row) {
?>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success" role="alert">
<?php echo $this->session->flashdata('success'); ?>
</div>
<?php endif; ?>
<div class="card mb-3">
<div class="card-header">
<a href="<?php echo site_url('dashboard/data_ruangan') ?>"><i class="fasfa-arrow-left"></i> Back</a>
</div>
<div class="card-body">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <form action="<?php echo site_url('dashboard/update_dataruangan') ?>" method="post" enctype="multipart/form-data">
                                            
                                            <div class="form-group row">
                                                <label for="name">Nama Ruangan*</label>
                                                <input class="form-control" type="text" name="nm_barang" value="<?php echo $row->nm_ruangan; ?>" placeholder="Nama Barang" required/>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-gradient-success">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
</div>
</div>
<?php } ?>