<div class="page-container">
<div class="main-content">
    <div class="container-fluid">
        <div class="page-header">
            <h2 class="header-title">Data Pengguna</h2>
        </div>  
        
        <div class="card">
            <div class="card-body">
                <a href="<?php echo site_url('dashboard/form_pengguna') ?>" class="btn btn-info btn-rounded btn-float">Tambah</a> 
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Username</th>
                            <th scope="col">Password</th> 
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    foreach ($tbl_pengguna as $key) {
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $key->nama; ?></td>
                        <td><?php echo $key->username; ?></td>
                        <td><?php echo $key->password; ?></td>
                        <td>
                            <a href="<?php echo site_url('dashboard/edit_data/' . $key->id_pengguna); ?>"  class="btn btn-warning btn-rounded btn-float">Edit</a>
                            <a href="<?php echo site_url('dashboard/hapus/' . $key->id_pengguna); ?>" class="btn btn-danger btn-rounded btn-float" onclick="myFunction();">Hapus</a>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<script>
function myFunction() {
    if (!confirm('Apakah Anda ingin menghapus?')) {
        event.preventDefault();
        return false;
    }
    return true;
}
</script>
