<script src="<?= base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/PACE/pace.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>     
    <script src="<?= base_url(); ?>assets/vendor/d3/d3.min.js"></script>
    <!-- endbuild -->

    <!-- build:js assets/js/app.min.js -->
    <!-- core js -->
    <script src="<?= base_url(); ?>assets/js/app.js"></script>
    <!-- configurator js -->
    <script src="<?= base_url(); ?>assets/js/configurator.js"></script>
    <!-- endbuild -->

    <!-- page js -->
    <script src="<?= base_url(); ?>assets/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/jvectormap-master/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/maps/vector-map-lib/jquery-jvectormap-world-mill.js"></script>
    <script src="<?= base_url(); ?>assets/js/dashboard/saas.js"></script>


    <script src="<?= base_url(); ?>assets/vendor/datatables/media/js/jquery.dataTables.js"></script>
    <script src="<?= base_url(); ?>assets/vendor/datatables/media/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/tables/data-table.js"></script>
    