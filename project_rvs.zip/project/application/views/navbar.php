<div class="app header-info-gradient side-nav-dark">
   <div class="layout">
      <div class="header navbar">
         <div class="header-container">
            <div class="nav-logo">
               <a href="Dashboard">
                  <div class="logo logo-dark"
                     style="background-image: url('<?= base_url(); ?>assets/images/logo/horizon.png')"></div>
                  <div class="logo logo-white"
                     style="background-image: url('<?= base_url(); ?>assets/images/logo/w.png')"></div>
               </a>
            </div>
            <ul class="nav-left">
               <li>
                  <a class="sidenav-fold-toggler" href="javascript:void(0);">
                     <i class="mdi mdi-menu"></i>
                  </a>
                  <a class="sidenav-expand-toggler" href="javascript:void(0);">
                     <i class="mdi mdi-menu"></i>
                  </a>
               </li>
               <li class="search-box">
                  <a class="search-toggle" href="javascript:void(0);">
                     <i class="search-icon mdi mdi-magnify"></i>
                     <i class="search-icon-close mdi mdi-close-circle-outline"></i>
                  </a>
               </li>
               <li class="search-input">
                  <input class="form-control" type="text" placeholder="Type to search...">
                  <div class="search-predict">
                     <div class="search-wrapper scrollable">
                        <div class="p-v-10">
                           <span class="display-block m-v-5 p-h-20 text-gray">
                              <i class="ti-file p-r-5"></i>
                              <span>Files</span>
                           </span>
                           <ul class="list-media">
                              <li class="list-item">
                                 <a href="javascript:void(0);" class="media-hover p-h-20">
                                    <div class="media-img">
                                       <div class="icon-avatar bg-success">
                                          <i class="mdi mdi-file-outline"></i>
                                       </div>
                                    </div>
                                 </a>
                              </li>
                           </ul>
                        </div>
                        <div class="m-h-20 border top"></div>
                        <div class="p-v-10">
                           <span class="display-block m-v-5 p-h-20 text-gray">
                              <i class="ti-user p-r-5"></i>
                              <span>Members</span>
                           </span>
                           <ul class="list-media">
                              <li class="list-item">
                                 <a href="javascript:void(0);" class="conversation-toggler media-hover p-h-20">
                                    <div class="media-img">
                                       <img src="<?= base_url(); ?>assets/images/avatars/thumb-3.jpg" alt="">
                                    </div>
                                    <div class="info">
                                       <span class="title p-t-10">Debra Stewart</span>
                                    </div>
                                 </a>
                              </li>
                              <li class="list-item">
                                 <a href="javascript:void(0);" class="conversation-toggler media-hover p-h-20">
                                    <div class="media-img">
                                       <img src="<?= base_url(); ?>assets/images/avatars/thumb-5.jpg" alt="">
                                    </div>
                                    <div class="info">
                                       <span class="title p-t-10">Jane Hunt</span>
                                    </div>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="search-footer">
                        <span>You are Searching for '<b class="text-dark"><span
                                 class="serach-text-bind"></span></b>'</span>
                     </div>
                  </div>
               </li>
            </ul>
            <ul class="nav-right">
               <li class="dropdown dropdown-animated scale-left">

                  <ul class="dropdown-menu dropdown-grid col-3 dropdown-lg">

                     <ul class="list-media overflow-y-auto relative scrollable" style="max-height: 300px">
                        <li class="list-item border bottom">
                           <a href="javascript:void(0);" class="media-hover p-15">
                              <div class="media-img">
                                 <div class="icon-avatar bg-primary">
                                    <i class="ti-settings"></i>
                                 </div>
                              </div>

                           </a>
                        </li>
                     </ul>



                  </ul>
               </li>
               <li class="user-profile dropdown dropdown-animated scale-left mr-3">
                  <a href="" class="dropdown-toggle" data-toggle="dropdown">
                     <img class="profile-img img-fluid" src="<?= base_url(); ?>assets/images/avatars/thumb-13.jpg"
                        alt="">
                  </a>
                  <ul class="dropdown-menu dropdown-md p-v-0">
                     <li>
                        <ul class="list-media">
                           <li class="list-item p-15">
                              <div class="media-img">
                                 <img src="<?= base_url(); ?>assets/images/avatars/thumb-13.jpg" alt="">
                              </div>
                              <div class="info">
                                 <span class="title text-semibold"><?= $this->session->userdata('username'); ?></span>
                                 <span class="sub-title">Username :
                                    <?= ($this->session->userdata('usname')); ?></span>
                              </div>
                           </li>
                        </ul>
                     </li>
                     <li role="separator" class="divider"></li>



                     <li>
                        <a href="<?= base_url('auth'); ?>">
                           <i class="ti-power-off p-r-10"></i>
                           <span>Logout</span>
                        </a>
                     </li>
                  </ul>
               </li>
               </li>
            </ul>
         </div>
      </div>
   </div>
</div>