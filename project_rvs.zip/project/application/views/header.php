<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>INVENAS</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" href="<?= base_url(); ?>assets/images/logo/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?= base_url(); ?>assets/images/logo/favicon.png">

    <!-- core dependcies css -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/bootstrap/dist/css/bootstrap.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/PACE/themes/blue/pace-theme-minimal.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/perfect-scrollbar/css/perfect-scrollbar.min.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/datatables/media/css/dataTables.bootstrap4.min.css" />


    <!-- page css -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/jvectormap-master/jquery-jvectormap-2.0.3.css" />

    <!-- core css -->
    <link href="<?= base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/themify-icons.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/app.css" rel="stylesheet">
</head>
    <div class="app header-info-gradient side-nav-dark">
        <div class="layout">
