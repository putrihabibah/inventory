<div class="page-container">
                <div class="main-content">
                    <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="card">
                                   <div class="card-header">
                                       <h4 class="card-title">Earning</h4>
                                   </div>
                                   <div class="card-body">
                                        <h2 class="font-weight-light font-size-28 m-b-0">$26,932</h2>
                                        <span>Sales:</span>
                                        <span class="text-dark">1,782</span>
                                   </div>
                                   <div class="m-b-15">
                                        <canvas id="earning-chart" class="chart" style="height: 170px;"></canvas>
                                    </div>
                                    <div class="row p-v-25">
                                        <div class="col border right">
                                            <div class="text-center">
                                                <span class="text-semibold d-block opacity-07">Margin</span>
                                                <span class="text-semibold">$17,312</span>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="text-center">
                                                <span class="text-semibold d-block opacity-07">Fees</span>
                                                <span class="text-semibold">$9,620</span>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>